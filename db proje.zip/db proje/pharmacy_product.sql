CREATE DATABASE  IF NOT EXISTS `pharmacy` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pharmacy`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pharmacy
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_name` varchar(45) NOT NULL,
  `dosage` double NOT NULL,
  `type` varchar(45) NOT NULL,
  `supplier_supplier_id` int(11) NOT NULL,
  `expire_expire_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`supplier_supplier_id`,`expire_expire_id`),
  KEY `fk_product_supplier1_idx` (`supplier_supplier_id`),
  KEY `fk_product_expire1_idx` (`expire_expire_id`),
  CONSTRAINT `fk_product_expire1` FOREIGN KEY (`expire_expire_id`) REFERENCES `expire` (`expire_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_supplier1` FOREIGN KEY (`supplier_supplier_id`) REFERENCES `supplier` (`supplier_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=291449 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (291429,'Ambien',5,'tablet',512,102540),(291430,'Amoxicillin',200,'capsula',519,102544),(291431,'Celexa',20,'tablet',500,102537),(291432,'Cialis',10,'tablet',519,102551),(291433,'Flomax',4,'capsula',510,102544),(291434,'Ibuprofen',1200,'tablet',519,102540),(291435,'Lexapro',10,'tablet',500,102537),(291436,'Lisinopril',10,'tablet',501,102540),(291437,'Lunesta',1,'tablet',510,102544),(291438,'Metformin',500,'tablet',500,102551),(291439,'Oxycodone',10,'tablet',519,102537),(291440,'Prilosec',20,'capsula',510,102544),(291441,'Prozac',90,'capsula',501,102540),(291442,'Tamiflu',75,'capsula',500,102537),(291443,'Ramadol',50,'tablet',501,102544),(291444,'Vicodin',500,'tablet',510,102551),(291445,'Viagra',100,'tablet',501,102555),(291446,'Welbutrin',75,'tablet',500,102551),(291447,'Xanax',2,'tablet',510,102555),(291448,'Zoloft',50,'tablet',501,102537);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-25 18:10:00
