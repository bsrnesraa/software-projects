CREATE DATABASE  IF NOT EXISTS `pharmacy` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pharmacy`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pharmacy
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(45) NOT NULL,
  `cust_address` varchar(45) NOT NULL,
  `cust_contact` varchar(45) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=378213 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (378193,'Kendall','Ap #540-6240 Convallis Rd.','1-524-410-4313'),(378194,'Dieter','P.O. Box 182, 5485 Massa. Av.','1-438-596-6962'),(378195,'Inez','607-1002 Tristique Street','117-8197'),(378196,'Isabelle','934-2115 Et Ave','167-6299'),(378197,'Dorian','148-2218 Adipiscing Avenue','1-419-526-3103'),(378198,'Kimberly','4183 Convallis Avenue','1-623-271-0949'),(378199,'Aladdin','9057 Facilisi. Rd.','1-896-152-6310'),(378200,'Ryan','P.O. Box 871, 1136 Accumsan St.','1-248-947-6050'),(378201,'Aquila','P.O. Box 208, 9960 Elit, St.','1-626-324-0529'),(378202,'Wesley','4577 Quis Street','950-1616'),(378203,'Derek','2486 In, Street','1-310-787-3055'),(378204,'Athena','383-2581 Pede. Rd.','849-8637'),(378205,'September','347-7837 Nunc Street','655-4273'),(378206,'Dustin','8184 Enim Av.','820-1628'),(378207,'Delilah','604-2718 Quis, Ave','396-4574'),(378208,'Idola','Ap #299-5948 Vel St.','1-153-492-4376'),(378209,'Herrod','657-8635 Etiam Av.','387-8532'),(378210,'Quin','4277 Pellentesque Av.','1-818-310-5113'),(378211,'Barry','Ap #687-2225 Egestas, St.','707-2991'),(378212,'Lila','Ap #367-1040 Phasellus Av.','1-377-470-1134');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-25 18:10:00
