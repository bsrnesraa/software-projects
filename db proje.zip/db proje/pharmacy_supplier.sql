CREATE DATABASE  IF NOT EXISTS `pharmacy` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pharmacy`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pharmacy
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_name` varchar(45) NOT NULL,
  `sup_address` varchar(45) CHARACTER SET big5 NOT NULL,
  `sup_contact` varchar(45) NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=520 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (500,'Diam Eu Associates','212-4402 Curabitur Rd.','419-6622'),(501,'Ornare Sagittis Felis LLP','P.O. Box 168, 7703 Vivamus Rd.','404-3810'),(502,'Donec Consulting','5795 Sagittis Road','865-5111'),(503,'Ornare Fusce Mollis Institute','4634 Massa St.','1-343-333-5235'),(504,'Egestas Hendrerit Neque Inc.','7979 Nec, St.','216-6479'),(505,'Eget LLC','Ap #850-9403 Primis Av.','973-8460'),(506,'Et Libero Incorporated','6702 Enim. Rd.','644-3604'),(507,'Consequat Industries','7564 Mattis. Street','1-593-406-7281'),(508,'In Company','P.O. Box 541, 6399 Diam. Rd.','1-542-609-2518'),(509,'Sagittis Semper Nam Limited','Ap #920-2709 Convallis Avenue','283-9998'),(510,'Quisque Ac Institute','894-2404 Odio Rd.','1-102-656-7639'),(511,'Tempus Risus Incorporated','916-1959 Velit. Road','1-335-637-1909'),(512,'Dui In Sodales Company','1206 At Ave','1-856-290-0683'),(513,'Sapien Molestie Foundation','1824 Neque. Road','804-1294'),(514,'Nulla Tincidunt LLC','Ap #873-6251 Nisi Rd.','1-496-381-4533'),(515,'Ipsum Donec Incorporated','140-4277 Magna. St.','1-531-286-0728'),(516,'Interdum Libero Institute','Ap #430-2592 Nec, Ave','829-2522'),(517,'Sed Dictum Proin Inc.','Ap #723-732 Mi Av.','573-3964'),(518,'Dapibus Id Blandit Industries','267-2230 Vulputate Av.','1-362-697-0642'),(519,'Nibh Aliquam Ornare Company','931-7364 Feugiat. Rd.','1-884-921-4517');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-25 18:10:01
