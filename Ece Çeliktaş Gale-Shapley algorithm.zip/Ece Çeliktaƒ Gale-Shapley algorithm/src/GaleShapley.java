import java.security.SecureRandom;
import java.util.*;

public class GaleShapley {

    private int pairCount;
    private PessimalityType pessimalityType;

    private List<String> menList;
    private List<String> womenList;
    private Map<String, List<String>> menPreferences;
    private Map<String, List<String>> womenPreferences;
    private Map<String, String> matchMap;

    private Random random = new SecureRandom();

    GaleShapley(int pairCount, PessimalityType pessimalityType) {
        this.pairCount = pairCount;
        this.pessimalityType = pessimalityType;
    }

    void initializePeople() {
        System.out.println("Creating the world...");

        menList = new ArrayList<>(pairCount);
        womenList = new ArrayList<>(pairCount);

        while (menList.size() < pairCount && womenList.size() < pairCount) {
            String man = "M" + (menList.size() + 1);
            String woman = "W" + (womenList.size() + 1);
            menList.add(man);
            womenList.add(woman);
        }

        System.out.println("World has " + menList.size() + " men and " + womenList.size() + " women.");
        System.out.print("Men:");
        printList(menList);
        System.out.print("Women:");
        printList(womenList);
    }

    void generatePreferences() {
        menPreferences = new HashMap<>(pairCount);
        womenPreferences = new HashMap<>(pairCount);

        for (String man : menList) {
            List<String> copyOfWomenList = new ArrayList<>(womenList);
            Collections.shuffle(copyOfWomenList, random);
            menPreferences.put(man, copyOfWomenList);
        }

        for (String woman: womenList) {
            List<String> copyOfMenList = new ArrayList<>(menList);
            Collections.shuffle(copyOfMenList, random);
            womenPreferences.put(woman, copyOfMenList);
        }

        printPreferences();
    }

    private void printPreferences() {
        System.out.println("Men preferences:");
        for (String man : menPreferences.keySet()) {
            List<String> preferences = menPreferences.get(man);
            System.out.print(man + " prefers: ");
            printList(preferences);
        }

        System.out.println("Women preferences:");
        for (String woman: womenPreferences.keySet()) {
            List<String> preferences = womenPreferences.get(woman);
            System.out.print(woman + " prefers: ");
            printList(preferences);
        }
    }

    void matchPeople() {
        if (pessimalityType == PessimalityType.MAN) {
            matchMap = new TreeMap<>();
            List<String> freeMen = new ArrayList<>(menList);

            while (!freeMen.isEmpty()) {
                String currentMan = freeMen.remove(0);
                List<String> currentManPreferences = menPreferences.get(currentMan);

                for (String woman : currentManPreferences) {
                    String otherMan = matchMap.get(woman);
                    if (otherMan == null) {
                        matchMap.put(woman, currentMan);
                        break;
                    } else {
                        List<String> currentWomanPreferences = womenPreferences.get(woman);
                        if (currentWomanPreferences.indexOf(currentMan) < currentWomanPreferences.indexOf(otherMan)) {
                            matchMap.put(woman, currentMan);
                            freeMen.add(otherMan);
                            break;
                        }
                    }
                }
            }
        } else {
            
        
         if  (pessimalityType == PessimalityType.WOMAN) {
            matchMap = new TreeMap<>();
            List<String> freeWomen = new ArrayList<>(womenList);

            while (!freeWomen.isEmpty()) {
                String currentWoman = freeWomen.remove(0);
                List<String> currentWomanPreferences = womenPreferences.get(currentWoman);

                for (String man : currentWomanPreferences) {
                    String otherWoman = matchMap.get(man);
                    if (otherWoman == null) {
                        matchMap.put(man, currentWoman);
                        break;
                    } else {
                        List<String> currentManPreferences = menPreferences.get(man);
                        if (currentManPreferences.indexOf(currentWoman) < currentManPreferences.indexOf(otherWoman)) {
                            matchMap.put(man, currentWoman);
                            freeWomen.add(otherWoman);
                            break;
            
                    }
                 }
              }
           }
        }
     }
    

        
        printMatches();
    }

    private void printMatches() {
        System.out.println("Matches:");
        for (String key : matchMap.keySet()) {
            System.out.println(key + " -> " + matchMap.get(key));
        }
    }

    private void printList(List<String> list) {
        System.out.print("{ ");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i));
            if (i != list.size() - 1)
                System.out.print(", ");
        }
        System.out.println(" }");
    }

        enum PessimalityType {
        MAN, WOMAN
    }

}

