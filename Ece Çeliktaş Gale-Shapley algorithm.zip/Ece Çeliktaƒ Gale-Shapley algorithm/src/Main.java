public class Main {

    public static void main(String... agrs) {
        GaleShapley matcher = new GaleShapley(4, GaleShapley.PessimalityType.MAN);
        matcher.initializePeople();
        matcher.generatePreferences();
        matcher.matchPeople();
    }

}

