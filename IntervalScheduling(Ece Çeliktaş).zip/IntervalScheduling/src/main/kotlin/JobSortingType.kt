enum class JobSortingType {
    FINISH_TIME
}