import kotlin.random.Random

fun main() {

    val jobList = mutableListOf<Job>()

    println("Creating ${Settings.JOB_COUNT} Jobs...")
    for (i in 0 until Settings.JOB_COUNT) {
        val jobLength = Random.nextInt(Settings.JOB_MIN_LENGTH, Settings.JOB_MAX_LENGTH + 1)
        val jobStartTime = Random.nextInt(0, 24)

        jobList.add(Job(jobStartTime, (jobStartTime + jobLength) % 24))
    }
    println("Current Job List: ${jobList.joinToString()}")

    println("Scheduling jobs...")
    val intervalScheduler = IntervalScheduler()
    val scheduledJobs = intervalScheduler.schedule(jobList)
    println("Scheduled Job List: ${scheduledJobs.joinToString()}")
}