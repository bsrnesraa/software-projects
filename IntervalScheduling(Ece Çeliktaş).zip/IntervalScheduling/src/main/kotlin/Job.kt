data class Job(
    val startTime: Int,
    val finishTime: Int
)