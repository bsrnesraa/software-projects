class JobSorter {

    companion object {

        fun sort(unsortedJobList: List<Job>, sortingType: JobSortingType): List<Job> {

            when (sortingType) {
                JobSortingType.FINISH_TIME -> {
                    return unsortedJobList.sortedBy { job -> job.finishTime }
                }
            }

        }

    }

}