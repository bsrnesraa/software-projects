abstract class Scheduler {

    abstract fun schedule(jobList: List<Job>): List<Job>

}