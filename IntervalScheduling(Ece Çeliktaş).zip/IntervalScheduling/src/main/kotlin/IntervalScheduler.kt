class IntervalScheduler : Scheduler() {

    override fun schedule(jobList: List<Job>): List<Job> {

        val scheduledJobs = mutableListOf<Job>()
        val sortedJobs = JobSorter.sort(jobList, JobSortingType.FINISH_TIME)

        sortedJobs.forEach { job ->
            if (scheduledJobs.isEmpty())
                scheduledJobs.add(job)
            else {
                if (job.startTime >= scheduledJobs.last().finishTime)
                    scheduledJobs.add(job)
            }
        }

        return scheduledJobs

    }


}