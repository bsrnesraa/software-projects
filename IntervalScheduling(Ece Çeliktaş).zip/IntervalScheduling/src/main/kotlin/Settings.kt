object Settings {

    const val JOB_COUNT = 5
    const val JOB_MIN_LENGTH = 1
    const val JOB_MAX_LENGTH = 5

}